#include <SPI.h>
#include <TFT_eSPI.h>
#include <WiFi.h>
TFT_eSPI tft = TFT_eSPI();  // 调用自定义库
const char *wifi_SSID="YXDZ_ESP32";  //保存AP的名称信息
const char *wifi_Password="ESP321234";  //保存AP的密码信息

void TFT_Init(void){
  tft.init();//屏幕初始化
  // 将“光标”设置在显示屏的左上角（0,0），然后选择字体4
  tft.setCursor(0, 0, 2);
  // 将字体颜色设置为白色，背景为黑色
  tft.setTextColor(TFT_RED, TFT_BLACK);
  tft.setRotation(4);
  tft.fillScreen(TFT_BLACK);//填充屏幕
  tft.println("Hello world");
}
void Wifi_SAT_Init(void){
  WiFi.begin("JinHai","12123434");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.println("waiting");    
    delay(500);
  }
}
void WiFi_Info(void){
    Serial.print("\nIP位址:");
 
  //WiFi.localIP()显示本机ip
  Serial.println(WiFi.localIP());
 
  Serial.print("WiFi RSSI: ");
 
  //WiFi.RSSI()显示信号强度
  Serial.println(WiFi.RSSI());
}
void Wifi_AP_Init(void){
  WiFi.softAP(wifi_SSID,wifi_Password);  //设置AP模式热点的名称和密码，密码可不填则发出的热点为无密码热点
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello ESP32!!");
  TFT_Init();
  //Wifi_AP_Init();
  Wifi_SAT_Init();

  delay(300);
}
 
void loop() {
  WiFi_Info();//显示wifi强度
  delay(500);
  // // put your main code here, to run repeatedly:
  // tft.setRotation(5);
  // tft.fillScreen(TFT_BLACK);//填充屏幕
  // tft.println("White text");
  // delay(300);
  // tft.setRotation(6);
  // tft.fillScreen(TFT_BLACK);//填充屏幕
  // tft.println("White text");
  // delay(300);
  // tft.setRotation(4);
  // tft.fillScreen(TFT_BLACK);//填充屏幕
  // tft.println("White text");
  // delay(300);
  // tft.init();//屏幕初始化
  // // 将“光标”设置在显示屏的左上角（0,0），然后选择字体4
  // tft.setCursor(0, 0, 4);
}