#include <SPI.h>
#include <TFT_eSPI.h>


TFT_eSPI tft = TFT_eSPI();  // 调用自定义库
 
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello ESP32C3!!");
  tft.init();//屏幕初始化
  // 将“光标”设置在显示屏的左上角（0,0），然后选择字体4
  tft.setCursor(0, 0, 4);
 
  // 将字体颜色设置为白色，背景为黑色
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  //tft.setRotation(2);
 
  tft.fillScreen(TFT_BLACK);//填充屏幕
 
  tft.println("White text");
}
 
void loop() {
  // put your main code here, to run repeatedly:
 
}